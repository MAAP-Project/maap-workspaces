ADE_OPTIONS = ["ade.dit.maap-project.org", "ade.uat.maap-project.org", "ade.maap-project.org"]
DEFAULT_ADE = "ade.maap-project.org"
DEFAULT_API = "api.maap-project.org"